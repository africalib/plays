const global = {
    //baseUrl: 'http://localhost:8000'
    baseUrl: 'https://africalib.gabia.io'
};